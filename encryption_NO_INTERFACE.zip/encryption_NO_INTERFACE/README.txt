TAG obtained successfully
C obtained successfully but it is necessary to add some states/ modify architecture in order to signal when C has to be sampled

Initial data:
s0_in <= x"00001000808c0001" 
s1_in <= x"ade5472935479cbf" 
s2_in <= x"123abcdebcfda450" 
s3_in <= x"dfcd4532ab87451c" 
s4_in <= x"5238795972fed354" 

Associated data <= x"00000000000000000000000001cedbaffdbceadfcbdfcfab7964578023652701"  
Plaintext <= x"00000000000000000000000001ce5baffdbcea04c7dfcfab7964a7ef23cd270b" 

expected C <= x"842a5dbf3c7ff89cf181cc0c7be1aa4626f086"
expected T <= x"204cdf9317d0bdae1d3508996059bae3"